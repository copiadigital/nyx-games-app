#!/usr/bin/env bash

cd /app \
  && npm install \
  && npm start